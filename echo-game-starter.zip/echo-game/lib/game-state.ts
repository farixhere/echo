export type EchoState = {
  orbTouched: boolean;
  doorUnlocked: boolean;
  memoryCount: number;
  hasSeenEcho: boolean;
};

export const initialEchoState: EchoState = {
  orbTouched: false,
  doorUnlocked: false,
  memoryCount: 0,
  hasSeenEcho: false
};
