'use client';

import { useEffect, useState } from 'react';
import { EchoState, initialEchoState } from '../lib/game-state';

const SAVE_KEY = 'echo-v1-state';

export default function EchoRoom() {
  const [state, setState] = useState<EchoState>(initialEchoState);
  const [hydrated, setHydrated] = useState(false);
  const [message, setMessage] = useState('The room is quiet. Something is waiting.');

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(SAVE_KEY);
      if (raw) setState({ ...initialEchoState, ...JSON.parse(raw) });
    } catch {}
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) window.localStorage.setItem(SAVE_KEY, JSON.stringify(state));
  }, [state, hydrated]);

  function touchOrb() {
    setState(s => ({ ...s, orbTouched: true, memoryCount: s.memoryCount + 1 }));
    setMessage(state.orbTouched ? 'It remembers your touch.' : 'A pulse moves through the room.');
  }

  function inspectDoor() {
    if (state.orbTouched) {
      setState(s => ({ ...s, doorUnlocked: true }));
      setMessage('The door reacts to something you did before.');
    } else {
      setMessage('The door is silent. Perhaps the room wants you to notice something else.');
    }
  }

  function enterDoor() {
    if (!state.doorUnlocked) return setMessage('The door will not move.');
    setState(s => ({ ...s, hasSeenEcho: true }));
    setMessage('Beyond the door, you hear the exact pulse you made earlier.');
  }

  function reset() {
    setState(initialEchoState);
    setMessage('Memory erased. The room is quiet again.');
    window.localStorage.removeItem(SAVE_KEY);
  }

  return (
    <main className="game-shell">
      <header className="hud">
        <div><span className="eyebrow">PROJECT 03</span><h1>ECHO</h1><p>The world remembers what you do.</p></div>
        <button className="reset" onClick={reset}>Reset memory</button>
      </header>

      <section className={`room ${state.orbTouched ? 'awakened' : ''}`} aria-label="The Room That Remembers">
        <div className="ambient ambient-one" /><div className="ambient ambient-two" />
        <div className="door-zone">
          <button className={`door ${state.doorUnlocked ? 'unlocked' : ''}`} onClick={state.doorUnlocked ? enterDoor : inspectDoor} aria-label="Mysterious door">
            <span>{state.doorUnlocked ? 'ENTER' : 'DOOR'}</span>
          </button>
        </div>
        <button className={`orb ${state.orbTouched ? 'active' : ''}`} onClick={touchOrb} aria-label="Mysterious orb">
          <span className="orb-core" />
          {state.orbTouched && <span className="ring ring-one" />}
          {state.orbTouched && <span className="ring ring-two" />}
        </button>
        <div className="stone" aria-hidden="true" />
        {state.hasSeenEcho && <div className="echo-trace" aria-hidden="true" />}
      </section>

      <section className="message" aria-live="polite"><span className="dot" />{message}</section>
      <div className="progress"><span>MEMORY</span><strong>{state.memoryCount}</strong><span className="separator">·</span><span>{state.hasSeenEcho ? 'ECHO FOUND' : state.doorUnlocked ? 'DOOR AWAKE' : state.orbTouched ? 'ROOM AWAKE' : 'DORMANT'}</span></div>
    </main>
  );
}
